import './App.css';
import Carousel from './components/Carousel/Carousel';

function App() {
  return (
      <Carousel />
  );
}

export default App;
